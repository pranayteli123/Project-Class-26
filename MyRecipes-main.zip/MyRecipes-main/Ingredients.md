Pasta: I like using penne- it’s the most typical way to make pink sauce pasta, but you can use any pasta you like.

Tomato passata: This is not the same thing as tomato paste. You’ll find jars labeled passata in the same section you find canned tomatoes and sauce. It’s basically pureed and strained uncooked or lightly cooked tomatoes. If you can’t find it, you can substitute tomato puree or tomato sauce.

The creamy part: A mix between heavy cream (whipping cream) and milk. This is another great way to keep the pasta from being too heavy with all heavy cream.

The flavoring: The sauce starts off with a base of olive oil and butter, in which we cook onion and garlic. This gets the flavor going.

Added to this are the spices: simply dried basil (can sub Italian seasoning if you want), red chili flakes, salt and pepper and a pinch of sugar which helps with the acidity of the tomatoes. The crumbled bouillon cube (you can use veggie stock too) adds a lot of flavor, depth and some salt to the dish too.

The cheese: I use mozzarella cheese that’s stirred into the sauce at the last minute making it gooey and delicious. You can also top the completed dish with some fresh Parmesan if desired or extra mozzarella.

