First make the pasta. You’ll cook it according to package instructions, until pasta is al dente, then you’ll drain the pasta but reserve a little pasta water. Be careful not too overcook, since it’ll get added back to the pink sauce and soften a little further.

Heat butter and olive oil in a large enough skillet to fit all the pasta ingredients over medium heat until the butter melts.

Next, add the diced onion and saute until softened. Once the onion is soft, the garlic goes in for another minute or until fragrant.

Add the tomato passata and all the herbs and simmer for just a few minutes.

The last step is adding the milk, the cream and the shredded mozzarella cheese and stirring until a thick pink sauce forms.

Add the cooked pasta back into the skillet and stir until the pasta is evenly coated in the sauce. If it’s too thick, add a splash of pasta water to loosen.

That’s it! A delicious meal in a flash!